#import <Flutter/Flutter.h>

@interface FlutterIjkPlugin : NSObject<FlutterPlugin>
@end
