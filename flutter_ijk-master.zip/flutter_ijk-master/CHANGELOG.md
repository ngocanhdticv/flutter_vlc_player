## 0.0.2

* Add completion listener to android side of the plugin

## 0.0.1

* TODO: Describe initial release.
