//
//  Generated file. Do not edit.
//

// clang-format off

#import "GeneratedPluginRegistrant.h"

#if __has_include(<flutter_ijk/FlutterIjkPlugin.h>)
#import <flutter_ijk/FlutterIjkPlugin.h>
#else
@import flutter_ijk;
#endif

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [FlutterIjkPlugin registerWithRegistrar:[registry registrarForPlugin:@"FlutterIjkPlugin"]];
}

@end
